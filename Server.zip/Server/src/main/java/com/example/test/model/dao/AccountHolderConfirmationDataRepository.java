package com.example.test.model.dao;

import com.example.test.model.AccountHolderConfirmationData;
import org.springframework.data.repository.CrudRepository;

public interface AccountHolderConfirmationDataRepository extends CrudRepository<AccountHolderConfirmationData,Integer> {


}
